//
//  ViewController.swift
//  StoryDigitalSystemTest
//
//  Created by Zahid Shaikh on 02/08/20.
//  Copyright © 2020 zahid. All rights reserved.
//

import UIKit

private var numberOfCards: Int = 5

class ViewController: UIViewController {
    
    @IBOutlet weak var kolodaView: KolodaView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var progressView: UIProgressView!
    fileprivate var dataSource: [CardModel] = []
    // MARK: Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
        
    }
    override var preferredStatusBarStyle: UIStatusBarStyle {
          return .lightContent
    }
    
    fileprivate func initialSetup(){
        let swipeDown = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeDown.direction = UISwipeGestureRecognizer.Direction.down
        self.kolodaView.addGestureRecognizer(swipeDown)
        progressView.progress = 0
        self.modalTransitionStyle = UIModalTransitionStyle.flipHorizontal
        self.activityIndicator.style = .large
        self.activityIndicator.color = .red
        loadData()
    }
    func setupProgress(value: Float,type: Int){
        let a : Float = type == 1 ? Float(value+1) : Float(value-1)
        let b : Float = Float(dataSource.count)
        let c = (a/b)
        //setupProgress(percent: Float(c))
        progressView.progress = c
    }
    // MARK: IBActions
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                print("Swiped right")
            case UISwipeGestureRecognizer.Direction.down:
                print("Swiped down")
            case UISwipeGestureRecognizer.Direction.left:
                print("Swiped left")
            case UISwipeGestureRecognizer.Direction.up:
                print("Swiped up")
            default:
                break
            }
        }
    }
    @IBAction func undoButtonTapped() {
        revertAction()
    }
    fileprivate func revertAction(){
        let cIndex = kolodaView.currentCardIndex
        if cIndex >= 1 {
            setupProgress(value: Float(cIndex), type: 2)
        }else {
            self.progressView.progress = 0
        }
        
        kolodaView?.revertAction()
    }
    fileprivate func showAlert(wih message: String){
        let alert = UIAlertController(title: message, message: nil, preferredStyle: .alert)
        let action1 = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alert.addAction(action1)
        DispatchQueue.main.async {
            self.present(alert , animated: true)
        }
    }
    fileprivate func loadData(){
        activityIndicator.startAnimating()
        guard let url = URL(string: "https://git.io/fjaqJ") else {
            self.activityIndicator.stopAnimating()
            self.showAlert(wih: "Invalid Url")
            return
        }
        
        let request = URLRequest(url: url)
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                self.activityIndicator.stopAnimating()
                self.activityIndicator.isHidden  = true
            }
            guard error == nil else {
                let returnMessage = "RequestFailed :->  \(String(describing: error!.localizedDescription))"
                self.showAlert(wih: returnMessage)
                return
            }
            
            do {
                if let responseString = String(data: data!, encoding: .utf8)?.replacingOccurrences(of: "/", with: "") {
                    let dataFromStr = Data(responseString.utf8)
                    let resData = try JSONDecoder().decode(Card.self, from: dataFromStr)
                    DispatchQueue.main.async {
                        self.dataSource = resData.data
                        self.kolodaView.dataSource = self
                        self.kolodaView.delegate = self
                    }
                    
                }
                
            }catch DecodingError.dataCorrupted(let context) where (context.underlyingError as NSError?)?.code == 3840 {
                self.showAlert(wih:"The given data was not valid JSON.")
            } catch { print(error) }
        }.resume()
    }
}

// MARK: KolodaViewDelegate

extension ViewController: KolodaViewDelegate {
    
    func kolodaDidRunOutOfCards(_ koloda: KolodaView) {
        progressView.progress = 0
        koloda.resetCurrentCardIndex()
    }
    func koloda(_ koloda: KolodaView, didSwipeCardAt index: Int, in direction: SwipeResultDirection) {
        
        setupProgress(value: Float(index), type: 1)
    }
    
//    func kolodaPanFinished(_ koloda: KolodaView, card: DraggableCardView) {
//        if koloda.visibleCardsDirection == .top {
//            revertAction()
//        }
//    }
    
    
}

// MARK: KolodaViewDataSource

extension ViewController: KolodaViewDataSource {
    
    func kolodaNumberOfCards(_ koloda: KolodaView) -> Int {
        return dataSource.count
    }
    
    func kolodaSpeedThatCardShouldDrag(_ koloda: KolodaView) -> DragSpeed {
        return .default
    }
    
    func koloda(_ koloda: KolodaView, viewForCardAt index: Int) -> UIView {
        // return //UIImageView(image: dataSource[Int(index)])
        let v = Bundle.main.loadNibNamed("CustomCardView", owner: self, options: nil)?[0] as! CustomCardView
        v.setupView(str: dataSource[index].text)
        return v
    }
    
    func koloda(_ koloda: KolodaView, viewForCardOverlayAt index: Int) -> OverlayView? {
        return nil//Bundle.main.loadNibNamed("OverlayView", owner: self, options: nil)?[0] as? OverlayView
    }
}

