//
//  CardModel.swift
//  StoryDigitalSystemTest
//
//  Created by Zahid Shaikh on 03/08/20.
//  Copyright © 2020 zahid. All rights reserved.
//

import Foundation

struct Card: Codable {
    let data: [CardModel]
    enum CodingKeys: String, CodingKey {
        case data
    }
//    init(from decoder: Decoder) throws {
//        let container = try decoder.container(keyedBy: CodingKeys.self)
//        let dataString = try container.decode(String.self, forKey: .data)
//        data = try JSONDecoder().decode([CardModel].self, from: Data(dataString.utf8))
//    }
}

// MARK: - Datum
struct CardModel: Codable {
    let id, text: String
    
    
}
