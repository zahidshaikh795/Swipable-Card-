//
//  CustomCardView.swift
//  StoryDigitalSystemTest
//
//  Created by Zahid Shaikh on 02/08/20.
//  Copyright © 2020 zahid. All rights reserved.
//

import UIKit

class CustomCardView: UIView {

    @IBOutlet weak var desLabel: UILabel! 
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    func setupView(str:String) {
        desLabel.text = str
    }

}
